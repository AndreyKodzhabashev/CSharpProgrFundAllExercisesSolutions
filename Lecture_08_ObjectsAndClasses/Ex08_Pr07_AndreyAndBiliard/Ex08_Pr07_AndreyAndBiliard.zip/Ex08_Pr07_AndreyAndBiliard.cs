﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ex08_Pr07_AndreyAndBiliard
{
    class Ex08_Pr07_AndreyAndBiliard
    {
        static void Main()
        {
            int ammount = int.Parse(Console.ReadLine());


            Dictionary<string, decimal> dictMenu = new Dictionary<string, decimal>();

            // TODO - to take the "firsr part" of the input - the list of goods in the "menu"
            for (int i = 0; i < ammount; i++)
            {
                //reading from the console and separating
                string[] currGood = Console.ReadLine().Split('-').ToArray();

                //declaring and initial. the product and its price
                string product = currGood[0];
                decimal price = decimal.Parse(currGood[1]);

                //checking if the product is already in the menu. If YES = updating its price, ELSE - adding it to the menu
                if (dictMenu.ContainsKey(product) == false)
                {
                    dictMenu.Add(product, 0m);
                }

                dictMenu[product] = price;

            }
            //DONE

            //TODO - creating a class Client and a list of object of the class Client to store all the Clients. The class Client is in a separate file
            List<Client> allClients = new List<Client>();

            //DONE

            //TODO - collecting "the second part" of the input: The clients name and their purchase
            while (true)
            {
                //reading from the Console
                string inputData = Console.ReadLine();

                //verificartion if the loop should be broken
                if (inputData.Equals("end of clients"))
                {
                    break;
                }

                //separating the properties of the purchase - client name, product and quantity
                string[] clientsProp = inputData
                    .Split(new char[] { '-', ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                //declaring and initial the properties of the clients purchase
                string clientName = clientsProp[0];
                string productToBuy = clientsProp[1];
                int quantity = int.Parse(clientsProp[2]);

                //checking if the "menu" contains the product to be purchased. If YES - creating a Client and collecting the data.
                //If NOT = we have to skip the current purchase
                if (dictMenu.ContainsKey(productToBuy) == false)
                {
                    continue;
                }

                Client currentClient = new Client(clientName);

                if (currentClient.ShopList.ContainsKey(productToBuy) == false)
                {
                    currentClient.ShopList.Add(productToBuy, 0);
                }
                currentClient.ShopList[productToBuy] += quantity;


                allClients.Add(currentClient);
            }

            foreach (var item in allClients.OrderBy(x => x.Name))
            {
                Console.WriteLine(item.Name);

                foreach (var product in item.ShopList)
                {
                    Console.WriteLine($"-- {product.Key} - {product.Value}");
                    item.TotalPrice += product.Value * dictMenu[product.Key];
                }

                Console.WriteLine($"Bill: {item.TotalPrice:F2} ");

            }
            Console.WriteLine($"Total bill: { allClients.Sum(x => x.TotalPrice):F2}");
        }
    }
}