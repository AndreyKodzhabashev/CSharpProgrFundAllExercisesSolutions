﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex08_Pr07_AndreyAndBiliard
{
    class Client
    {
        public Client(string name)
        {

            this.Name = name;
        }

        public string Name { get; set; }
        public Dictionary<string, int> ShopList = new Dictionary<string, int>();

        public decimal TotalPrice { get; set; }

    }
}
